let cor; //adicina cor ao fundo
let circuloX; //Horizontal
let circuloY; //Vertical

function setup() { // preparar e rodar o código de uma única vez

    createCanvas(600, 600); // São as medidas da tela
    background(color(100, 0, 0)); // define a cor do fundo
    
    cor = "color(random(0, 255), random(0, 255), random(0,255))"; //para definir um número entre 0 e 3
    circuloX = [0, 0, 0];
    circuloY = [random(height), random(height), random(height)];  //para definir um número entre 0 e 3
    }
function draw() {//função responsável por desenhar na tela
  fill(cor); //Para definir bordas no seu desenho
  // console.log(circuloX length);
  for (let contador in circuloX) {
    console.log(contador);
    circle(circuloX[contador], circuloY[contador], 50); //desenhar um circulo
    circuloX[contador] += random(0, 3); //para definir um número entre 0 e 3
    circuloY[contador] += random(-3, 3); //para definir um número entre 0 e 3
    
    if (circuloX[contador] >= width) {
      circuloX[contador] = 0;
      circuloY[contador] = random(height); //para definir um número entre 0 e 3
  }
}
   if (mouseIsPressed) {  //A funcao de pressionar o mouse
    cor = color(random(0, 255), random(0, 255), random(0, 255), random(0, 100)); //quando pressionar o mouse ira trocar a cor do circulo
  }
}