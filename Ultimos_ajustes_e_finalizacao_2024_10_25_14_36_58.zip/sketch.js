let palavra; ////uma variável global 

function setup() {
  createCanvas(400, 400); //Crie uma tela de 400 por 400 pixels

  palavra = palavraAleatoria(); //É a função que escolhe a palavra aleatóriamente
  
}

function palavraAleatoria() { //Define a função palavras aleatórias
  
  let palavras = ["Caminhante", "Caminho", "Caminha"]; //uma variável global chamada palavra
  
  return random(palavras); //Sorteia a palavra
}

function inicializaCores() { //É a função que inicia as cores
  background("white"); //Define a cor do quadro
  fill("black"); //define a cor das palavras
  textSize(64);  //Define o tamanho do texto
  textAlign(CENTER, CENTER); //Posiciona a palavra no centro
}

function palavraParcial(minimo, maximo) { //função palava parcial
  let quantidade = map(mouseX, minimo, maximo, 1, palavra.length); //é a função que ao passar p mouse a palavra aparece
  let parcial = palavra.substring(0, quantidade); //Define as quantidade letras que não iram aparecer
  return parcial;
}

function draw() { //É a função desenhar
  
  inicializaCores(); //inicia as cores

  let texto = palavraParcial(0, width); //nicia as cores
    
  text(texto, 200, 200); //Define a localização do texto
  
}

function modoNoturno(horario) { //]Função modo noturno
  if (horario > 18) { //define o horário que entrara do modo noturno
    console.log("Você precisa ligar o modo escuro!"); //Define a ativação do modo noturno
  } else {
    console.log("Modo noturno não é necessário neste momento."); //Define a desativação do modo noturno
  }
}

modoNoturno(15); //define a itencidade minima do modo noturno 
modoNoturno(20); //define a itencidade minima do modo noturno 