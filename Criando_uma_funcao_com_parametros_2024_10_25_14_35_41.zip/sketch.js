let palavra; //uma variável global 

function setup() { //uma variável global chamada palavra
  createCanvas(400, 400); //Essa função cria uma tela de 400 por 400
  palavra = palavraAleatoria(); //É a função que escolhe a palavra aleatóriamente
  
}

function palavraAleatoria() { //Define a função palavras aleatórias
  let palavras = ["Caminhante", "Caminho", "Caminha"]; //uma variável global chamada palavra  
  return random(palavras); //Sorteia a palavra
}

function inicializaCores() { //É a função que inicia as cores
  background("white"); //Define a cor do quadro
  fill("black"); //define a cor das palavras
  textSize(64); //Define o tamanho do texto
  textAlign(CENTER, CENTER); //Posiciona a palavra no centro
}
function palavraParcial(minimo, maximo) { //função palava parcial
  let quantidade = map(mouseX, minimo, maximo, 1, palavra.length); //é a função que ao passar p mouse a palavra aparece
  let parcial = palavra.substring(0, quantidade); //Define as quantidade letras que não iram aparecer
  return parcial; 
}

function draw() {  //É a função desenhar
  inicializaCores() //nicia as cores
  let parcial = palavraParcial(0, width); //É a váriavel máxima
  text(parcial, 200, 200);  //Define a localização do texto
  
}