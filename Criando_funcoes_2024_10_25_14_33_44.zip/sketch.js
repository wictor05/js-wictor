function setup() {  //Essa função cria uma tela de 400 por 400
  createCanvas(400, 400); //cria um espaço branco de 400 pixels para a direita e 400 pixels para baixo
}

function inicializaCores() {  //Inicia as cores
  
  background("white"); //Essa função define a cor do quadro
  fill("black"); //Dfine a cor das letras
  textSize(64); //Define o tamanho das letras
  textAlign(CENTER, CENTER); //Posiciona a palavra no centro o quadro
}

function draw() { //Ela fica desenhando constantemente
  
  inicializaCores(); //Essa função inicia o desenho

  let maximo = width; //Define o máximo de várialvel 
  let minimo = 0 //Define o minimo da Váialvel
  let palavra = "Caminhante"; //Deifine a palavra que irá ser desenhada
  let quantidade = map(mouseX, 0, width, 1, palavra.length); //Ao passar o mouse a palavra aparece
  let parcial = palavra.substring(0, quantidade); //Define as quantidade letras que não iram aparecer
  text(parcial, 200, 200); //Define a posição do texto
  
}