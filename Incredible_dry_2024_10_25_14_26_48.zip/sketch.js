function setup() {
  createCanvas(700, 700);  //tamanho da tela
  background("white")    //cor da tela
}

function draw() {         //a função desenhar
  stroke("blue");       //a cor da borda do desenho
  fill("red");          //a cor do desenho
  
  
  if (mouseIsPressed) {  //a função de pressionar e desenhar
    rect(mouseX, mouseY, 20, 35);   //o tamanho do desenho 
  }
}
