let cor; //Cor variavel 
let posicaoHorizontal; // Estabelecer a posição
let posicaoVertical; 

function setup() {  //Funçao responsavel por preparar e rodar o código em uma unica vez

    createCanvas(400, 400); //Responsavel pelo tamanho da tela
    background("white"); // responsalvel pela cor da tela
    cor = color(random(0, 255), random(0, 256), random(0,215)); //define a cor do circulo da tela
    posicaoHorizontal = 200; //posição horizontal da tela
    posicaoVertical = 200; // posição vertical da tela
    }
    
function draw() {
    
     fill(cor); // defina a cor do cor do circulo
    circle(posicaoHorizontal, posicaoVertical, 50); // define o tamanho do circulo

  
  
  if(mouseX < posicaoHorizontal) {  //defina que acompanhe o mouse para esquerda
    posicaoHorizontal = posicaoHorizontal - 1; //defina a velocidade do mouse para esquerda

  }
  
  if(mouseX > posicaoHorizontal) { //Defina que acompanhe o mouse para a direita
    posicaoHorizontal = posicaoHorizontal + 1; //defina a velocidade do mouse para direita
    
  }
  
  if(mouseY < posicaoVertical) { //Defina que o mouse acompanhe o mouse para baixo
    posicaoVertical --;  //defina a velocidade do mouse para baixo
  }
  
  if(mouseY > posicaoVertical){ //Defina que acompanhe o mouse para cima
    posicaoVertical ++;  //defina a velocidade do mouse para cima
  }
  
  if(mouseIsPressed){ //ao pressionar o mouse mudara de cor
    cor = color(random(0,255), random(0,255), random(0,255)), random(0,100);  //a cor ao pressionar o mouse
 } 

}